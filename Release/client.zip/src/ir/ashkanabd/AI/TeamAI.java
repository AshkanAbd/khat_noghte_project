package ir.ashkanabd.AI;

import ir.ashkanabd.game.Cell;
import ir.ashkanabd.game.AI;

public class TeamAI extends AI {

    @Override
    public String getTeamName() {
        return "team";
    }

    @Override
    public Cell think(Cell[][] map) {
        for (int i = 0; i < this.getColNumber(); i++) {
            for (int j = 0; j < this.getRowNumber(); j++) {
                if (map[i][j].isFree()) {
                    System.out.println(map[i][j]);
                    return map[i][j];
                }
            }
        }
        return null;
    }
}
