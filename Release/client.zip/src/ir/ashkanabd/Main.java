package ir.ashkanabd;

import ir.ashkanabd.game.Handler;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        new Handler();
    }
}
