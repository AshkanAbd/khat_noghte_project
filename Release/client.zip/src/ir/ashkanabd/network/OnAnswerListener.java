package ir.ashkanabd.network;

public interface OnAnswerListener {
    void onAnswer(String line);
}
